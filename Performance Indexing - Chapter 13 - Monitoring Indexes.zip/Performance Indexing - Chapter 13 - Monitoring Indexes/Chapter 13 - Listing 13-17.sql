--Listing 13-17.  Create SQL Trace Session
USE master
GO
-- Create a Queue
DECLARE @rc INT
  ,@TraceID int
  ,@maxfilesize BIGINT = 50 --Maximum .trc file size in MB
  ,@FileName NVARCHAR(256) = 'c:\temp\IndexingMethod' --File name and path, minus the extension
EXEC @rc = sp_trace_create @TraceID output, 0, @FileName, @maxfilesize, NULL
if (@rc != 0) RAISERROR('Error creating trace file',16,1)
SELECT * FROM sys.traces WHERE id = @TraceID