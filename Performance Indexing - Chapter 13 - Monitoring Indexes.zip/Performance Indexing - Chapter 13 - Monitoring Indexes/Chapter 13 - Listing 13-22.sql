--Listing 13-22. Create and start extended events session
USE master
GO

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name = 'EventTracingforIndexTuning')
	DROP EVENT SESSION [EventTracingforIndexTuning] ON SERVER

CREATE EVENT SESSION [EventTracingforIndexTuning] ON SERVER 
ADD EVENT sqlserver.rpc_completed(
    ACTION(package0.process_id
	,sqlserver.client_app_name
	,sqlserver.client_hostname
	,sqlserver.database_id
	,sqlserver.database_name
	,sqlserver.nt_username
	,sqlserver.session_id
	,sqlserver.sql_text
	,sqlserver.username)),
ADD EVENT sqlserver.sql_batch_completed(
    ACTION(package0.process_id
	,sqlserver.client_app_name
	,sqlserver.client_hostname
	,sqlserver.database_id
	,sqlserver.database_name
	,sqlserver.nt_username
	,sqlserver.session_id
	,sqlserver.sql_text
	,sqlserver.username)) 
ADD TARGET package0.event_file(SET filename=N'EventTracingforIndexTuning')
WITH (STARTUP_STATE=ON)
GO

ALTER EVENT SESSION [EventTracingforIndexTuning] ON SERVER STATE = START
GO

