--Listing 13-19.  Add Filters to SQL Trace Session
USE master
GO
DECLARE @intfilter INT = 5
  ,@FileName NVARCHAR(256) = 'c:\temp\IndexingMethod'
  ,@TraceID INT
SET @TraceID = (SELECT id FROM sys.traces WHERE path LIKE @FileName+'%')
--Remove system databases from output
EXEC sp_trace_setfilter @TraceID, 3, 0, 4, @intfilter