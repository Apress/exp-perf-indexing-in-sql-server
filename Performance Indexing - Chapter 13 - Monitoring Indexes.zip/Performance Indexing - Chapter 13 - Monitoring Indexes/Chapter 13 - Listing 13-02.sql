--Listing 13-2. Performance Counter Snapshot Script
USE IndexingMethod
GO

IF OBJECT_ID('tempdb..#Baseline') IS NOT NULL
DROP TABLE #Baseline

SELECT
GETDATE() AS sample_time
,pc1.object_name
,pc1.counter_name
,pc1.instance_name
,pc1.cntr_value
,pc1.cntr_type
,x.cntr_value AS base_cntr_value
INTO #Baseline
FROM sys.dm_os_performance_counters pc1
OUTER APPLY (
SELECT cntr_value
FROM sys.dm_os_performance_counters pc2
WHERE pc2.cntr_type = 1073939712
AND UPPER(pc1.counter_name) = UPPER(pc2.counter_name)
AND pc1.[object_name] = pc2.[object_name]
AND pc1.instance_name = pc2.instance_name) x
WHERE pc1.cntr_type IN (272696576,1073874176)
	AND (pc1.[object_name] LIKE '%:Access Methods%'
	AND (pc1.counter_name LIKE 'Forwarded Records/sec%'
	OR pc1.counter_name LIKE 'FreeSpace Scans/sec%'
	OR pc1.counter_name LIKE 'Full Scans/sec%'
	OR pc1.counter_name LIKE 'Index Searches/sec%'
	OR pc1.counter_name LIKE 'Page Splits/sec%'))
	OR (pc1.[object_name] LIKE '%:Buffer Manager%'
	AND (pc1.counter_name LIKE 'Page life expectancy%'
	OR pc1.counter_name LIKE 'Page lookups/sec%'))
	OR (pc1.[object_name] LIKE '%:Locks%'
	AND (pc1.counter_name LIKE 'Lock Wait Time (ms)%'
	OR pc1.counter_name LIKE 'Lock Waits/sec%'
	OR pc1.counter_name LIKE 'Number of Deadlocks/sec%'))
	OR (pc1.[object_name] LIKE '%:SQL Statistics%'
	AND pc1.counter_name LIKE 'Batch Requests/sec%');
 
WAITFOR DELAY '00:00:10';

INSERT INTO dbo.IndexingCounters
(create_date, server_name, object_name, counter_name, instance_name, Calculated_Counter_value)
SELECT GETDATE()
	,LEFT(pc1.object_name,CHARINDEX(':',pc1.object_name)-1)
	,SUBSTRING(pc1.object_name,1+CHARINDEX(':',pc1.object_name), LEN(pc1.object_name))
	,pc1.counter_name
	,pc1.instance_name
	,CASE WHEN pc1.cntr_type = 65792 THEN pc1.cntr_value
		WHEN pc1.cntr_type = 272696576 THEN COALESCE((1.*pc1.cntr_value-x.cntr_value)
			/NULLIF(DATEDIFF(s, sample_time, GETDATE()),0),0)
		WHEN pc1.cntr_type = 537003264 THEN COALESCE((1.*pc1.cntr_value)
			/NULLIF(base.cntr_value,0),0)
		WHEN pc1.cntr_type = 1073874176 THEN COALESCE((1.*pc1.cntr_value-x.cntr_value)
			/NULLIF(base.cntr_value-x.base_cntr_value,0)
			/NULLIF(DATEDIFF(s, sample_time, GETDATE()),0),0)
		END as real_cntr_value
FROM sys.dm_os_performance_counters pc1
OUTER APPLY (SELECT cntr_value, base_cntr_value, sample_time
	FROM #Baseline b
	WHERE b.object_name = pc1.object_name
	AND b.counter_name = pc1.counter_name
	AND b.instance_name = pc1.instance_name) x
OUTER APPLY (SELECT cntr_value
	FROM sys.dm_os_performance_counters pc2
	WHERE pc2.cntr_type = 1073939712
	AND UPPER(pc1.counter_name) = UPPER(pc2.counter_name)
	AND pc1.[object_name] = pc2.[object_name]
	AND pc1.instance_name = pc2.instance_name) base
WHERE pc1.cntr_type IN (65792,272696576,537003264,1073874176)
	AND (pc1.[object_name] LIKE '%:Access Methods%'
	AND (pc1.counter_name LIKE 'Forwarded Records/sec'
	OR pc1.counter_name LIKE 'FreeSpace Scans/sec%'
	OR pc1.counter_name LIKE 'Full Scans/sec%'
	OR pc1.counter_name LIKE 'Index Searches/sec%'
	OR pc1.counter_name LIKE 'Page Splits/sec%'))
	OR (pc1.[object_name] LIKE '%:Buffer Manager%'
	AND (pc1.counter_name LIKE 'Page life expectancy%'
	OR pc1.counter_name LIKE 'Page lookups/sec%'))
	OR (pc1.[object_name] LIKE '%:Locks%'
	AND (pc1.counter_name LIKE 'Lock Wait Time (ms)%'
	OR pc1.counter_name LIKE 'Lock Waits/sec%'
	OR pc1.counter_name LIKE 'Number of Deadlocks/sec%'))
	OR (pc1.[object_name] LIKE '%:SQL Statistics%'
	AND pc1.counter_name LIKE 'Batch Requests/sec%');