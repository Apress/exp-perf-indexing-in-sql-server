--Listing 13-23. Stop extended events session
USE master
GO

ALTER EVENT SESSION [EventTracingforIndexTuning] ON SERVER STATE = STOP
GO

