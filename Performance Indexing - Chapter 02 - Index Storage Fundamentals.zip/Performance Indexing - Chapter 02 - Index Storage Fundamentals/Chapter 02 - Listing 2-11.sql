--Listing 2-11.  DBCC PAGE Syntax
DBCC PAGE ( { database_name | database_id | 0}, file_number, page_number
      [,print_option ={0|1|2|3} ])