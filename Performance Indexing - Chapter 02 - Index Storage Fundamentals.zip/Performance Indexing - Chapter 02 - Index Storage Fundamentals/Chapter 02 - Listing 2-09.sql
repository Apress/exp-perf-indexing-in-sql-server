--Listing 2-9  sys.dm_db_database_page_allocations Syntax

SELECT * FROM sys.dm_db_database_page_allocations ({database_id}, {TableId | NULL}
	, {IndexId | NULL}, { PartitionId | NULL }, {DETAILED | LIMITED})