--Listing 2-13.  DBCC PAGE with Page Header Only Print Option
DBCC TRACEON(3604)
DBCC PAGE(0,1,310,0)