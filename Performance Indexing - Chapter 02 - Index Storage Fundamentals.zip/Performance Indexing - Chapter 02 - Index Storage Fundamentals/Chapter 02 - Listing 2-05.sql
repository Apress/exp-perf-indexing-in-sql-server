--Listing 2-5.  DBCC EXTENTINFO Example Four
USE Chapter2Internals
GO

CREATE TABLE dbo.IndexInternalsTwo
    (
    RowID INT IDENTITY(1,1)
    ,FillerData CHAR(8000)
    );

INSERT INTO dbo.IndexInternalsTwo
VALUES ('Demo'),('Demo'),('Demo'),('Demo'),('Demo')
   ,('Demo'),('Demo'),('Demo'),('Demo');

DBCC EXTENTINFO(0, IndexInternalsTwo, -1)
GO