--Listing 2-15.  DBCC PAGE with Hex Data Print Option
USE Chapter2Internals
GO

DBCC TRACEON(3604)
DBCC PAGE(0,1,310,2)