--Listing 2-12.  DBCC IND Query for DBCC PAGE Examples
USE [Chapter2Internals];
GO
if object_id('dbo.IndexInternalsFour') is not null
drop table dbo.IndexInternalsFour

CREATE TABLE dbo.IndexInternalsFour
    (
    RowID int IDENTITY(1,1) NOT NULL
    ,FillerData varchar(2000) NULL
    ,CONSTRAINT PK_IndexInternalsFour PRIMARY KEY CLUSTERED ([RowID] ASC)
    );

INSERT INTO dbo.IndexInternalsFour (FillerData)
VALUES (REPLICATE(1,2000)),(REPLICATE(2,2000)),(REPLICATE(3,2000))
   ,(REPLICATE(4,2000)),(REPLICATE(5,25));

SELECT
allocated_page_file_id AS PageFID
,allocated_page_page_id AS PagePID
,allocated_page_iam_file_id AS IAMFID
,allocated_page_iam_page_id AS IAMPID
,index_id AS IndexID
,allocation_unit_type_desc AS iam_chain_type
,page_type_desc
,page_level AS IndexLevel
,next_page_file_id AS NextPageFID
,next_page_page_id AS NextPagePID
,previous_page_file_id AS PrevPageFID
,previous_page_page_id AS PrevPagePID
FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('dbo.IndexInternalsFour'), 1, NULL, 'DETAILED')
WHERE is_allocated = 1;
