--Listing 2-6.  DBCC IND Syntax
DBCC IND ( {'dbname' | dbid}, {'table_name' | table_object_id},
      {'index_name' | index_id | -1})