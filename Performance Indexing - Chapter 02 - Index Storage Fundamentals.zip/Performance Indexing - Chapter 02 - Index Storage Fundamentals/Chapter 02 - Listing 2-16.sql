--Listing 2-16.  DBCC PAGE with Row Data Print Option
USE Chapter2Internals
GO

DBCC TRACEON(3604)
DBCC PAGE(0,1,311,3) -- Data page
DBCC PAGE(0,1,310,3) -- Index page