--Listing 2-14.  DBCC PAGE with Hex Rows Print Option
DBCC TRACEON(3604)
DBCC PAGE(0,1,310,1)