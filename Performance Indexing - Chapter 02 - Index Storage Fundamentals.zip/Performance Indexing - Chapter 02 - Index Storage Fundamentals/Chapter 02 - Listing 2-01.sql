--Listing 2-1.  DBCC EXTENTINFO Syntax
DBCC EXTENTINFO ( {database_name | database_id | 0}
  , {table_name | table_object_id}, { index_name | index_id | -1}
  , { partition_id | 0}