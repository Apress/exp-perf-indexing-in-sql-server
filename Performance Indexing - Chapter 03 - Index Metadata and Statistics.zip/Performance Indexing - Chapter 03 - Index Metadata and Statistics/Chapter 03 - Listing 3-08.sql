--Listing 3-8.  Sample DML queries dbo.SalesOrderHeaderStats
USE AdventureWorks2014
GO

UPDATE dbo.SalesOrderHeaderStats
set OrderDate = GETDATE()
WHERE SalesOrderID % 500 = 1

--execute code in Listing 3-7

UPDATE dbo.SalesOrderHeaderStats
SET SalesOrderNumber = SalesOrderNumber
WHERE SalesOrderID % 400 = 1

--execute code in Listing 3-7

UPDATE dbo.SalesOrderHeaderStats
SET SalesOrderNumber = REVERSE(SalesOrderNumber)
WHERE SalesOrderID % 400 = 1

--execute code in Listing 3-7

SET IDENTITY_INSERT dbo.SalesOrderHeaderStats ON
INSERT INTO dbo.SalesOrderHeaderStats (SalesOrderID
,OrderDate
,SalesOrderNumber)
SELECT SalesOrderID
,OrderDate
,SalesOrderNumber
FROM Sales.SalesOrderHeader
WHERE SalesOrderID > 63658
SET IDENTITY_INSERT dbo.SalesOrderHeaderStats OFF

--execute code in Listing 3-7

DELETE FROM dbo.SalesOrderHeaderStats
WHERE SalesOrderID <= 63658

--execute code in Listing 3-7

