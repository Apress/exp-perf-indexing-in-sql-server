--Listing 3-1.  DBCC SHOW_STATISTICS Syntax
DBCC SHOW_STATISTICS ( table_or_indexed_view_name, target )
[ WITH [ < options > ]