--Listing 3-2.  DBCC SHOW_STATISTICS for Index on Sales.SalesOrderDetail Table
USE AdventureWorks2014
GO

DBCC SHOW_STATISTICS ( 'Sales.SalesOrderDetail'
, PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID)
