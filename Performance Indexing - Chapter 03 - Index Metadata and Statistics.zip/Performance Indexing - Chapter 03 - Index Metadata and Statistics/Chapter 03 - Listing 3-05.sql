--Listing 3-5.  sys.dm_db_stats_properties Syntax

sys.dm_db_stats_properties (object_id, stats_id)
