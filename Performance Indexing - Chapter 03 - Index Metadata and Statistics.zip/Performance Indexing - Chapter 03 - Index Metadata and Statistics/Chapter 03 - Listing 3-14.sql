--Listing 3-14.  Index Lookup Query
USE AdventureWorks2014
GO

SELECT ProductID, CarrierTrackingNumber
FROM Sales.SalesOrderDetail
WHERE ProductID = 778;