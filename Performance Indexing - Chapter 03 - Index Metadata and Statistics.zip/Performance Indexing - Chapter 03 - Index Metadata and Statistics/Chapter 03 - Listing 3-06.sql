--Listing 3-6.  Prepare tables for sys.dm_db_stats_properties review
USE AdventureWorks2014
GO

IF OBJECT_ID('dbo.SalesOrderHeaderStats') IS NOT NULL
	DROP TABLE dbo.SalesOrderHeaderStats

SELECT SalesOrderID
,OrderDate
,SalesOrderNumber
INTO dbo.SalesOrderHeaderStats
FROM Sales.SalesOrderHeader
WHERE SalesOrderID <= 63658

CREATE CLUSTERED INDEX CIX_SalesOrderHeaderStats 
	ON dbo.SalesOrderHeaderStats(SalesOrderID)
CREATE INDEX CIX_SalesOrderHeaderStats_OrderDate 
	ON dbo.SalesOrderHeaderStats(OrderDate)
CREATE INDEX CIX_SalesOrderHeaderStats_SalesOrderNumber 
	ON dbo.SalesOrderHeaderStats(SalesOrderNumber)
