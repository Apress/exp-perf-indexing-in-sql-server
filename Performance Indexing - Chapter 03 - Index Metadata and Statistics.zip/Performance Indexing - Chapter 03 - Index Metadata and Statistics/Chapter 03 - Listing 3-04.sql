--Listing 3-4.  STATS_DATE Syntax
STATS_DATE ( object_id, stats_id )