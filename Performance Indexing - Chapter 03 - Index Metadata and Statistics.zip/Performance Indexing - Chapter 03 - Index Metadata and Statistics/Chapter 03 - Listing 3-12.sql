--Listing 3-12.  Index Scan Queries
USE AdventureWorks2014
GO
SELECT * FROM Sales.SalesOrderDetail
GO
SELECT * FROM Sales.SalesOrderDetail
WHERE CarrierTrackingNumber = '4911-403C-98'
GO