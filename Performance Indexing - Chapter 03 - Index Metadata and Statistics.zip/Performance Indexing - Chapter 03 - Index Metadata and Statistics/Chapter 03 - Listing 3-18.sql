--Listing 3-18.  Update for Sales.SalesOrderDetail
USE AdventureWorks2014
GO

UPDATE Sales.SalesOrderDetail
SET UnitPriceDiscount = 0.01
WHERE UnitPriceDiscount = 0.00;