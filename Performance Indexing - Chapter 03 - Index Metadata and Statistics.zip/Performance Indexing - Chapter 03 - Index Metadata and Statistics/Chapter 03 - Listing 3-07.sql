--Listing 3-7.  sys.dm_db_stats_properties query for dbo.SalesOrderHeaderStats
USE AdventureWorks2014
GO

SELECT 
	OBJECT_SCHEMA_NAME(s.object_id)
	+'.'+OBJECT_NAME(s.object_id) AS object_name
	,s.name as statistics_name
	,x.last_updated
	,x.rows
	,x.rows_sampled
	,x.steps
	,x.unfiltered_rows
	,x.modification_counter
FROM sys.stats s
	CROSS APPLY sys.dm_db_stats_properties(s.object_id, s.stats_id) x
WHERE s.object_id = OBJECT_ID('dbo.SalesOrderHeaderStats')
