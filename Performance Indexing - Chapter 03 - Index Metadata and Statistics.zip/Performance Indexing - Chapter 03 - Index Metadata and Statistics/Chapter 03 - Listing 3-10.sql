--Listing 3-10.  Index Seek Queries
USE AdventureWorks2014
GO

SELECT * FROM Sales.SalesOrderDetail
WHERE SalesOrderID = 43659;

SELECT * FROM Sales.SalesOrderDetail
WHERE SalesOrderID BETWEEN 43659 AND 44659;