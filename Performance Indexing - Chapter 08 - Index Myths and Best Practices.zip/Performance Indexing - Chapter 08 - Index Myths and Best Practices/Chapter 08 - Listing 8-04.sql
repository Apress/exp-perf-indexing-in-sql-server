--Listing 8-4.  I/O Statistics for Table with an Index
Table 'MythOne'. Scan count 1, logical reads 16, physical reads 0, read-ahead reads 0,  
lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.