--Listing 8-7.  Extended Event Session for Lock Acquired and Released
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name = 'MythThreeXevents')
	DROP EVENT SESSION [MythThreeXevents] ON SERVER
GO

CREATE EVENT SESSION [MythThreeXevents] ON SERVER
ADD EVENT sqlserver.lock_acquired(SET collect_database_name=(1)
  ACTION(sqlserver.sql_text)
  WHERE [sqlserver].[session_id]=(58) AND [object_id]=(1383675977)),
ADD EVENT sqlserver.lock_released(
  ACTION(sqlserver.sql_text)
  WHERE [sqlserver].[session_id]=(58) AND [object_id]=(1383675977))
ADD TARGET package0.ring_buffer
WITH (EVENT_RETENTION_MODE=NO_EVENT_LOSS,MAX_DISPATCH_LATENCY=1 SECONDS)
GO

ALTER EVENT SESSION [MythThreeXevents] ON SERVER STATE = START
GO