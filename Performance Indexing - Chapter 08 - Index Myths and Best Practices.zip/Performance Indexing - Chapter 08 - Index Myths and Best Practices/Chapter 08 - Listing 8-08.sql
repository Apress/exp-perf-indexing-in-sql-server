--Listing 8-8.  Online index operations on non-clustered index creation 
USE AdventureWorks2014
GO

CREATE INDEX IX_MythThree_ONLINE ON MythThree (Column1) WITH (ONLINE = ON);
GO

CREATE INDEX IX_MythThree ON MythThree (Column1);
GO
