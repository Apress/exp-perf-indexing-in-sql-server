--Listing 8-14.  Create and Populate Myth Five Table
DBCC TRACEON (3604);
GO

DBCC PAGE (AdventureWorks2014, 1, 24189, 2);
GO