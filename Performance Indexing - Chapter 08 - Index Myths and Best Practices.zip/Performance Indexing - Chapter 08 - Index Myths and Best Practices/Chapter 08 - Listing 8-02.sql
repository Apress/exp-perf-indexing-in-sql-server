--Listing 8-2.  I/O Statistics for Table with No Index
Table 'MythOne'. Scan count 1, logical reads 1497, physical reads 0, read-ahead reads 0, 
lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
