--Listing 8-11.  Query Using Right-most Column in Index
USE AdventureWorks2014
GO

SELECT ShipDate FROM dbo.MythFour
WHERE ShipDate = '2011-07-17 00:00:00.000'