--Listing 8-10.  Query Using Left-most Column in Index
USE AdventureWorks2014
GO

SELECT OrderDate FROM dbo.MythFour
WHERE OrderDate = '2011-07-17 00:00:00.000'