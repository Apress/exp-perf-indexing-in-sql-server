--Listing 8-12.  Query Using Middle Column in Index
USE AdventureWorks2014
GO

SELECT DueDate FROM dbo.MythFour
WHERE DueDate = '2011-07-17 00:00:00.000'