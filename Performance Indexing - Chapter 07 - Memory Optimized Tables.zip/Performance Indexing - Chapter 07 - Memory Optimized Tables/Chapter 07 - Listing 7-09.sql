--Listing 7-9. Query memory-optimzed tables with order by statement
USE MemOptIndexing
GO

SET STATISTICS TIME ON

SELECT TOP 100 *
FROM dbo.SalesOrderHeader_high
ORDER BY SalesOrderID

SELECT TOP 100 *
FROM dbo.SalesOrderHeader_high_range
ORDER BY SalesOrderID

SET STATISTICS TIME OFF