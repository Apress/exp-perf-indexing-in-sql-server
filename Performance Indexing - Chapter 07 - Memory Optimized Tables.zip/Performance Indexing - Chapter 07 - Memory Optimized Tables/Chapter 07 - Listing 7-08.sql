--Listing 7-8. Query memory-optimzed tables with range scan
USE MemOptIndexing
GO

SET STATISTICS TIME ON

SELECT * 
FROM dbo.SalesOrderHeader_high
WHERE SalesOrderID BETWEEN 100 AND 10000
ORDER BY SalesOrderID

SELECT * 
FROM dbo.SalesOrderHeader_high_range
WHERE SalesOrderID BETWEEN 100 AND 10000
ORDER BY SalesOrderID

SET STATISTICS TIME OFF