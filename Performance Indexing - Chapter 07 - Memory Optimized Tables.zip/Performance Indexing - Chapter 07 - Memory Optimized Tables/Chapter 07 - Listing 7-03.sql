--Listing 7-3.  Output from creating and querying memory-optimized table
(31465 row(s) affected)

(31465 row(s) affected)
Memory Optimized Table

 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.
SQL Server parse and compile time: 
   CPU time = 0 ms, elapsed time = 1 ms.

(31465 row(s) affected)

 SQL Server Execution Times:
   CPU time = 78 ms,  elapsed time = 310 ms.
Traditional Table

 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.

(31465 row(s) affected)
Table 'SalesOrderHeader'. Scan count 1, logical reads 689, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 47 ms,  elapsed time = 785 ms.

 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.
