--Listing 7-2.  Create memory-optimized table
USE MemOptIndexing
GO
IF OBJECT_ID('dbo.SalesOrderHeader') IS NOT NULL
	DROP TABLE dbo.SalesOrderHeader

CREATE TABLE dbo.SalesOrderHeader(
	SalesOrderID int NOT NULL,
	OrderDate datetime,
	DueDate datetime,
	ShipDate datetime,
	[Status] tinyint,
	CustomerID int,
	SalesPersonID int,
	CONSTRAINT IX_SalesOrderHeader_Hash PRIMARY KEY 
		NONCLUSTERED HASH (SalesOrderID) 
		WITH (BUCKET_COUNT = 35000)) 
	WITH (MEMORY_OPTIMIZED = ON)

IF  OBJECT_ID('tempdb..#tempHeader') IS NOT NULL
	DROP TABLE #tempHeader

SELECT SalesOrderID
	,OrderDate
	,DueDate
	,ShipDate
	,[Status]
	,CustomerID
	,SalesPersonID
INTO #tempHeader
FROM AdventureWorks2014.sales.SalesOrderHeader

INSERT INTO dbo.SalesOrderHeader
SELECT SalesOrderID
	,OrderDate
	,DueDate
	,ShipDate
	,[Status]
	,CustomerID
	,SalesPersonID
FROM #tempHeader

SET STATISTICS IO ON
SET STATISTICS TIME ON
PRINT 'Memory Optimized Table'
SELECT * 
FROM dbo.SalesOrderHeader
ORDER BY SalesOrderID


PRINT 'Traditional Table'
SELECT *
FROM AdventureWorks2014.sales.SalesOrderHeader
ORDER BY SalesOrderID

SET STATISTICS IO OFF
SET STATISTICS TIME OFF
