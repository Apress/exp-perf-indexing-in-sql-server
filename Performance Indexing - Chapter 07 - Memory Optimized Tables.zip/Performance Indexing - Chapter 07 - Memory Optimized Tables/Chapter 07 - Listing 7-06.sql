--Listing 7-6. Query memory-optimzed tables with hash indexes
USE MemOptIndexing
GO

SET STATISTICS TIME ON

PRINT 'Memory Optimized Table with 1000 buckets'
SELECT * 
FROM dbo.SalesOrderHeader_low
WHERE SalesOrderID in (42, 5000, 12344, 123562, 373457)
ORDER BY SalesOrderID

PRINT 'Memory Optimized Table with 1,000,000 buckets'
SELECT * 
FROM dbo.SalesOrderHeader_high
WHERE SalesOrderID in (42, 5000, 12344, 123562, 373457)
ORDER BY SalesOrderID

SET STATISTICS TIME OFF
