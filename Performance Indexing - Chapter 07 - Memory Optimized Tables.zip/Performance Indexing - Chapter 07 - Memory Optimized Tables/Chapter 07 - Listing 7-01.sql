--Listing 7-1.  Preparing database for memory-optimized tables 
USE master
GO

IF EXISTS(SELECT * FROM sys.databases WHERE name = 'MemOptIndexing')
	DROP DATABASE MemOptIndexing
GO

CREATE DATABASE MemOptIndexing 
GO

ALTER DATABASE MemOptIndexing 
	ADD FILEGROUP memoryOptimizedFG CONTAINS MEMORY_OPTIMIZED_DATA

--This file location may change in your environment
ALTER DATABASE MemOptIndexing 
	ADD FILE (name='memoryOptimizedData'
		,filename='C:\Program Files\Microsoft SQL Server\MSSQL12.SQL2014\MSSQL\DATA\memoryOptimizedData') 
		TO FILEGROUP memoryOptimizedFG 
ALTER DATABASE MemOptIndexing SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT=ON
GO
