--Listing 7-4. Create memory-optimzed tables with hash indexes
USE MemOptIndexing
GO

IF OBJECT_ID('dbo.SalesOrderHeader_low') IS NOT NULL
	DROP TABLE dbo.SalesOrderHeader_low

CREATE TABLE dbo.SalesOrderHeader_low(
	SalesOrderID int NOT NULL
	,Column1 uniqueidentifier
	,CONSTRAINT IX_SalesOrderHeader_Hash_low PRIMARY KEY 
		NONCLUSTERED HASH (SalesOrderID) 
		WITH (BUCKET_COUNT = 1000)) 
	WITH (MEMORY_OPTIMIZED = ON);

WITH L1(z) AS (SELECT 0 UNION ALL SELECT 0)
, L2(z) AS (SELECT 0 FROM L1 a CROSS JOIN L1 b)
, L3(z) AS (SELECT 0 FROM L2 a CROSS JOIN L2 b)
, L4(z) AS (SELECT 0 FROM L3 a CROSS JOIN L3 b)
, L5(z) AS (SELECT 0 FROM L4 a CROSS JOIN L4 b)
, L6(z) AS (SELECT TOP 1000000 0 FROM L5 a CROSS JOIN L5 b)
INSERT INTO dbo.SalesOrderHeader_low
SELECT ROW_NUMBER() OVER (ORDER BY z) AS RowID, NEWID()
FROM L6;
GO

IF OBJECT_ID('dbo.SalesOrderHeader_high') IS NOT NULL
	DROP TABLE dbo.SalesOrderHeader_high

CREATE TABLE dbo.SalesOrderHeader_high(
	SalesOrderID int NOT NULL
	,Column1 uniqueidentifier
	,CONSTRAINT IX_SalesOrderHeader_hash_high PRIMARY KEY 
		NONCLUSTERED HASH (SalesOrderID) 
		WITH (BUCKET_COUNT = 1000000)) 
	WITH (MEMORY_OPTIMIZED = ON);

WITH L1(z) AS (SELECT 0 UNION ALL SELECT 0)
, L2(z) AS (SELECT 0 FROM L1 a CROSS JOIN L1 b)
, L3(z) AS (SELECT 0 FROM L2 a CROSS JOIN L2 b)
, L4(z) AS (SELECT 0 FROM L3 a CROSS JOIN L3 b)
, L5(z) AS (SELECT 0 FROM L4 a CROSS JOIN L4 b)
, L6(z) AS (SELECT TOP 1000000 0 FROM L5 a CROSS JOIN L5 b)
INSERT INTO dbo.SalesOrderHeader_high
SELECT ROW_NUMBER() OVER (ORDER BY z) AS RowID, NEWID()
FROM L6;
