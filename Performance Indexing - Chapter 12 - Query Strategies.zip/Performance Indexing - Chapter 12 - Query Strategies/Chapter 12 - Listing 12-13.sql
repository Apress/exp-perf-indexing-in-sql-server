--Listing 12-13.  Implicit Conversion Queries
USE AdventureWorks2014
GO

SET STATISTICS IO ON
DECLARE @FirstName nvarchar(100)
SET @FirstName = 'Gail';

SELECT FirstName, LastName FROM PersonPerson
WHERE FirstName = @FirstName
OPTION (RECOMPILE);

GO
DECLARE @FirstName varchar(100)
SET @FirstName = 'Gail';

SELECT FirstName, LastName FROM PersonPerson
WHERE FirstName = @FirstName
OPTION (RECOMPILE);