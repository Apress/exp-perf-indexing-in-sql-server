--Listing 12-5.  Concatenation Without Spaces
USE AdventureWorks2014
GO
SET STATISTICS IO ON;

SELECT BusinessEntityID, FirstName, LastName
FROM Person.Person
WHERE FirstName + LastName = 'GustavoAchong';
