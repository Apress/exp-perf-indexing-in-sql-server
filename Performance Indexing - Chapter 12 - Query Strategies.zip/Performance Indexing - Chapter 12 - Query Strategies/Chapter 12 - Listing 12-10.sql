--Listing 12-10.  Queries on FirstName Gustavo
USE AdventureWorks2014
GO

SET STATISTICS IO ON 

SELECT BusinessEntityID, FirstName, LastName
FROM Person.Person
WHERE FirstName = 'Gustavo';

SELECT BusinessEntityID, FirstName, LastName
FROM Person.Person
WHERE RTRIM(FirstName) = 'Gustavo';