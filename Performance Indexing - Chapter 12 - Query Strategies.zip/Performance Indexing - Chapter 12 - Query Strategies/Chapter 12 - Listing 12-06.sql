--Listing 12-6.  Query with Concatenation Removed
USE AdventureWorks2014
GO

SET STATISTICS IO ON;

SELECT BusinessEntityID, FirstName, LastName
FROM Person.Person
WHERE FirstName = 'Gustavo'
AND LastName = 'Achong';