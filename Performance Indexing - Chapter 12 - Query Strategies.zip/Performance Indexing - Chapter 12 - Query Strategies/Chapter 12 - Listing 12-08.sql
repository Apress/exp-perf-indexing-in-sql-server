--Listing 12-8.  Computed Column Queries
USE AdventureWorks2014
GO

SET STATISTICS IO ON 

SELECT BusinessEntityID, FirstName, LastName, FirstLastName
FROM Person.Person
WHERE FirstLastName = 'Gustavo Achong';

SELECT BusinessEntityID, CalculateValue
FROM Person.Person
WHERE CalculateValue = 198;