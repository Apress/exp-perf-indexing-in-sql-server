--Listing 12-7.  Add Computed Columns to Person.Person
USE AdventureWorks2014
GO

ALTER TABLE Person.Person
ADD FirstLastName AS (FirstName + ' ' + LastName)
,CalculateValue AS (BusinessEntityID * EmailPromotion);