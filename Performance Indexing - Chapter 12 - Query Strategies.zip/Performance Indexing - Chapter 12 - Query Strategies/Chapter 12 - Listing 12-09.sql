--Listing 12-9.  Computed Column Indexes
USE AdventureWorks2014
GO
CREATE INDEX IX_PersonPerson_FirstLastName ON Person.Person(FirstLastName);
CREATE INDEX IX_PersonPerson_CalculateValue ON Person.Person(CalculateValue);