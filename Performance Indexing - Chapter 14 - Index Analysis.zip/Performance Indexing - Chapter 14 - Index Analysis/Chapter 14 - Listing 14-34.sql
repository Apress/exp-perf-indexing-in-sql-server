--Listing 14-34.  DTA Command with XML Input File
dta -ix "c:\temp\SessionCon?g.xml"