--Listing 14-08.  Full Scans Example Query
USE AdventureWorks2014
GO
SELECT * FROM Sales.SalesOrderHeader
GO 10