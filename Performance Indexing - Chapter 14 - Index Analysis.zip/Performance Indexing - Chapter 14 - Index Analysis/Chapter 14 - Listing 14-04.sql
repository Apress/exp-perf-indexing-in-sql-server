--Listing 14-04.  Rebuild Heap Script
USE [IndexingMethod]
GO
ALTER TABLE dbo.HeapExample REBUILD