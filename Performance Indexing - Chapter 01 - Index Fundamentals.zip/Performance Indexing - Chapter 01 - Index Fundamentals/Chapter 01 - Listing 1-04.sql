--Listing 1-4.  DROP INDEX Syntax
DROP INDEX
    index_name ON <object>
  [ WITH ( <drop_clustered_index_option> [ ,�n ] ) ]