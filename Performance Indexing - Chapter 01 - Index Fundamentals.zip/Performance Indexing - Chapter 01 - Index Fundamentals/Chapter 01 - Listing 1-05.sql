--Listing 1-5.  DROP INDEX Options
MAXDOP = max_degree_of_parallelism
  | ONLINE = { ON | OFF }
 | MOVE TO { partition_scheme_name ( column_name )
      | filegroup_name
      | "default"
      }
 [ FILESTREAM_ON { partition_scheme_name
      | filestream_filegroup_name
      | "default" } ]