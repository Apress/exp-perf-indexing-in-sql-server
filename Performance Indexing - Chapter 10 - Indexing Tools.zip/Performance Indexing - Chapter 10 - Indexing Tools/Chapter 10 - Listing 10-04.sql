--Listing 10-4.  DDL Statement to Drop Index missing_index_SalesOrderHeader
USE AdventureWorks2014
GO

DROP INDEX Sales.SalesOrderHeader.missing_index_SalesOrderHeader;