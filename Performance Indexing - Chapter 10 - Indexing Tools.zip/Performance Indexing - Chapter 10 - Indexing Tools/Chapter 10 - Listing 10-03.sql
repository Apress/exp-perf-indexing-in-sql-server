--Listing 10-3.  Index from Missing Index DMOs
USE AdventureWorks2014
GO

CREATE NONCLUSTERED INDEX missing_index_SalesOrderHeader
ON Sales.SalesOrderHeader([DueDate], [OrderDate])
INCLUDE ([CustomerID])