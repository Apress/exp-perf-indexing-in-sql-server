--Listing 10-5.  Database Engine Tuning Advisor Index Recommendations
use [AdventureWorks2014]
go

CREATE NONCLUSTERED INDEX [_dta_index_SalesOrderHeader_7_1266103551__K4_K3_11] ON [Sales].[SalesOrderHeader]
(
	[DueDate] ASC,
	[OrderDate] ASC
)
INCLUDE ( 	[CustomerID]) WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]
go
