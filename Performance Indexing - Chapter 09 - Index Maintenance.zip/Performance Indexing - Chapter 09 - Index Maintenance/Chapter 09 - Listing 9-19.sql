--Listing 9-19.  Impact of inserts on columnstore table
USE ContosoRetailDW
GO

SET STATISTICS IO ON 

SELECT DateKey, COUNT(*)
FROM dbo.FactOnlineSalesCI
GROUP BY DateKey

ALTER INDEX ALL ON dbo.FactOnlineSalesCI REBUILD

SELECT DateKey, COUNT(*)
FROM dbo.FactOnlineSalesCI
GROUP BY DateKey

SELECT * 
FROM sys.column_store_row_groups
WHERE object_id = OBJECT_ID('dbo.FactOnlineSalesCI')
ORDER BY row_group_id DESC

SET STATISTICS IO OFF