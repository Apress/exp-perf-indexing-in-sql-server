--Listing 9-7.  Create Table for UPDATE Operations
USE AdventureWorks2014
GO

UPDATE dbo.UpdateOperations
SET JunkValue = REPLICATE('X', 2000)
WHERE RowID % 5 = 1