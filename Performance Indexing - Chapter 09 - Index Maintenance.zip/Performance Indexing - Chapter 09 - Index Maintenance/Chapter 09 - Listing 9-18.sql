--Listing 9-18.  Prepare columnstore table
USE ContosoRetailDW
GO

IF OBJECT_ID('dbo.FactOnlineSalesCI') IS NOT NULL
	DROP TABLE dbo.FactOnlineSalesCI

CREATE TABLE dbo.FactOnlineSalesCI(
	[OnlineSalesKey] [int] NOT NULL,
	[DateKey] [datetime] NOT NULL,
	[StoreKey] [int] NOT NULL,
	[ProductKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [int] NULL,
	[SalesQuantity] [int] NOT NULL,
	[SalesAmount] [money] NOT NULL,
	[ReturnQuantity] [int] NOT NULL,
	[ReturnAmount] [money] NULL,
	[DiscountQuantity] [int] NULL,
	[DiscountAmount] [money] NULL,
	[TotalCost] [money] NOT NULL,
	[UnitCost] [money] NULL,
	[UnitPrice] [money] NULL,
	[ETLLoadID] [int] NULL,
	[LoadDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL
) 

INSERT INTO dbo.FactOnlineSalesCI
SELECT * 
FROM dbo.FactOnlineSales

CREATE CLUSTERED COLUMNSTORE INDEX FactOnlineSalesCI_CCI ON dbo.FactOnlineSalesCI

DECLARE @i int = 1

WHILE @i <= 5
BEGIN
	INSERT INTO dbo.FactOnlineSalesCI
	SELECT TOP 1000 * 
	FROM dbo.FactOnlineSales
	ALTER INDEX ALL ON dbo.FactOnlineSalesCI REORGANIZE 
		WITH (COMPRESS_ALL_ROW_GROUPS = ON)
	SET @i += 1
END

WHILE @i <= 10
BEGIN
	INSERT INTO dbo.FactOnlineSalesCI
	SELECT TOP 105000 * 
	FROM dbo.FactOnlineSales
	SET @i += 1
END

SELECT * 
FROM sys.column_store_row_groups
WHERE object_id = OBJECT_ID('dbo.FactOnlineSalesCI')
ORDER BY row_group_id DESC