--Listing 9-12.  Performing DELETE Operation
USE AdventureWorks2014
GO

DELETE dbo.DeleteOperations
WHERE RowID % 100 BETWEEN 1 AND 50