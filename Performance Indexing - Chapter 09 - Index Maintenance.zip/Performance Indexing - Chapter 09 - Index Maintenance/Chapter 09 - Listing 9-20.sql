--Listing 9-20.  Delete operations on a clustered columnstore index
USE ContosoRetailDW
GO

SET STATISTICS IO ON 

SELECT DateKey, COUNT(*)
FROM dbo.FactOnlineSalesCI
GROUP BY DateKey

DELETE FROM dbo.FactOnlineSalesCI
WHERE DateKey < '2008-01-01'

SELECT DateKey, COUNT(*)
FROM dbo.FactOnlineSalesCI
GROUP BY DateKey

ALTER INDEX ALL ON dbo.FactOnlineSalesCI REBUILD

SELECT DateKey, COUNT(*)
FROM dbo.FactOnlineSalesCI
GROUP BY DateKey

SET STATISTICS IO OFF