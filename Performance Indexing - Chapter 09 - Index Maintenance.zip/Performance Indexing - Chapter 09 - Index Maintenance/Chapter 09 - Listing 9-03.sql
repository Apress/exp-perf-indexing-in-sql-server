--Listing 9-3.  INSERT into Uniqueidentifier Table
USE AdventureWorks2014
GO

INSERT INTO dbo.UsingUniqueidentifier (Name, JunkValue)
SELECT name, REPLICATE('X', 2000)
FROM sys.objects