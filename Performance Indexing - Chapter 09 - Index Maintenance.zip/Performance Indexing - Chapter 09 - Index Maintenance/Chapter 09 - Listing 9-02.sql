--Listing 9-2.  View INSERT Index Fragmentation
USE AdventureWorks2014
GO

SELECT index_type_desc
  ,index_depth
  ,index_level
  ,page_count
  ,record_count
  ,CAST(avg_fragmentation_in_percent as DECIMAL(6,2)) as avg_frag_in_percent
  ,fragment_count AS frag_count
  ,avg_fragment_size_in_pages AS avg_frag_size_in_pages
  ,CAST(avg_page_space_used_in_percent as DECIMAL(6,2)) as avg_page_space_used_in_percent
FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('dbo.UsingUniqueidentifier'),NULL,NULL,'DETAILED')