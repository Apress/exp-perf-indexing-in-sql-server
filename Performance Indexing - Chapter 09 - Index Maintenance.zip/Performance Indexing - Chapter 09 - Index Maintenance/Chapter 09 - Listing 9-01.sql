--Listing 9-1.  Populate Usinguniqueidentifier Table
USE AdventureWorks2014
GO

IF OBJECT_ID('dbo.Usinguniqueidentifier') IS NOT NULL
    DROP TABLE dbo.Usinguniqueidentifier;

CREATE TABLE dbo.Usinguniqueidentifier
(
RowID uniqueidentifier CONSTRAINT DF_GUIDValue DEFAULT NEWID()
,Name sysname
,JunkValue varchar(2000)
);
INSERT INTO dbo.Usinguniqueidentifier (Name, JunkValue)
SELECT name, REPLICATE('X', 2000)
FROM sys.columns
CREATE CLUSTERED INDEX CLUS_Usinguniqueidentifier ON dbo.Usinguniqueidentifier(RowID);