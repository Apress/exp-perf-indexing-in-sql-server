--Listing 9-8.  Create Non-clustered Index for UPDATE operations
USE AdventureWorks2014
GO

CREATE NONCLUSTERED INDEX IX_Name ON dbo.UpdateOperations(Name) INCLUDE (JunkValue);