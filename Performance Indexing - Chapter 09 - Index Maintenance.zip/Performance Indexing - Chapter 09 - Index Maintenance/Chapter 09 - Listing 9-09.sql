--Listing 9-9.  UPDATE Operation to Change Index Key Value
USE AdventureWorks2014
GO

UPDATE dbo.UpdateOperations
SET Name = REVERSE(Name)
WHERE RowID % 9 = 1