--Listing 9-32.  sp_updatestats Syntax
sp_updatestats [ [ @resample = ] 'resample']