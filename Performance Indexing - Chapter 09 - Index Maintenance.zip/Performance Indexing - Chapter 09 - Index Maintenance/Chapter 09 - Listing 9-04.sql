--Listing 9-4.  Create Non-Clustered Index
USE AdventureWorks2014
GO

CREATE NONCLUSTERED INDEX IX_Name ON dbo.UsingUniqueidentifier(Name) INCLUDE (JunkValue);