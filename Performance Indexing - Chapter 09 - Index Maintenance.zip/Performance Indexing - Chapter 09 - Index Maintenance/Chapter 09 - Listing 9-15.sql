--Listing 9-15.  Shrink Operation
DBCC SHRINKDATABASE (Fragmentation)