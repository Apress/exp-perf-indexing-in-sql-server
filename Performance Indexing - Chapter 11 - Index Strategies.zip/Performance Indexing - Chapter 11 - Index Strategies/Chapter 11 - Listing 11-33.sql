--Listing 11-32.  Setup for Row Compression 
USE AdventureWorks2014
GO
IF OBJECT_ID('dbo.NoCompression') IS NOT NULL
  DROP TABLE dbo.NoCompression;

IF OBJECT_ID('dbo.RowCompression') IS NOT NULL
  DROP TABLE dbo.RowCompression;

SELECT SalesOrderID
    ,SalesOrderDetailID
    ,CarrierTrackingNumber
    ,OrderQty
    ,ProductID
    ,SpecialOfferID
    ,UnitPrice
    ,UnitPriceDiscount
    ,LineTotal
    ,rowguid
    ,ModifiedDate
INTO dbo.NoCompression
FROM Sales.SalesOrderDetail;

SELECT SalesOrderID
    ,SalesOrderDetailID
    ,CarrierTrackingNumber
    ,OrderQty
    ,ProductID
    ,SpecialOfferID
    ,UnitPrice
    ,UnitPriceDiscount
    ,LineTotal
    ,rowguid
    ,ModifiedDate
INTO dbo.RowCompression
FROM Sales.SalesOrderDetail;