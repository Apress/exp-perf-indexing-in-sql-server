--Listing 11-20.  Covering Index Pattern
USE AdventureWorks2014
GO

CREATE INDEX IX_Contacts_FirstNameLastNameIsActive ON dbo.Contacts(FirstName, LastName, 
IsActive);

SET STATISTICS IO ON;

SELECT ContactID, FirstName, LastName, IsActive FROM dbo.Contacts
WHERE FirstName = 'Catherine'
AND LastName = 'Cox';