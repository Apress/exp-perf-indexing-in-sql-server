--Listing 11-22.  Included Columns Pattern
USE AdventureWorks2014
GO

CREATE INDEX IX_Contacts_FirstNameINC ON dbo.Contacts(FirstName)
       INCLUDE (LastName, IsActive, EmailAddress);

SET STATISTICS IO ON;

SELECT ContactID, FirstName, LastName, EmailAddress FROM dbo.Contacts
WHERE FirstName = 'Catherine';