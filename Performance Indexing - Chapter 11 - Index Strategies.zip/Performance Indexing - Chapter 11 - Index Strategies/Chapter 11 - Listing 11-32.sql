--Listing 11-32.  Create fact table with clustered columnstore Index
USE ContosoRetailDW
GO

IF OBJECT_ID('dbo.FactSales_CCI') IS NOT NULL
	DROP TABLE FactSales_CCI

CREATE TABLE dbo.FactSales_CCI(
	SalesKey int NOT NULL,
	DateKey datetime NOT NULL,
	channelKey int NOT NULL,
	StoreKey int NOT NULL,
	ProductKey int NOT NULL,
	PromotionKey int NOT NULL,
	CurrencyKey int NOT NULL,
	UnitCost money NOT NULL,
	UnitPrice money NOT NULL,
	SalesQuantity int NOT NULL,
	ReturnQuantity int NOT NULL,
	ReturnAmount money NULL,
	DiscountQuantity int NULL,
	DiscountAmount money NULL,
	TotalCost money NOT NULL,
	SalesAmount money NOT NULL,
	ETLLoadID int NULL,
	LoadDate datetime NULL,
	UpdateDate datetime NULL
	)

INSERT INTO dbo.FactSales_CCI
SELECT * FROM dbo.FactSales

CREATE CLUSTERED COLUMNSTORE INDEX FactSales_CStore ON dbo.FactSales_CCI 

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

SELECT dd.CalendarQuarter
      ,dpc.ProductCategoryName
      , COUNT(*) As TotalRows
      ,SUM(SalesQuantity) AS TotalSales
FROM dbo.FactSales_CCI fs
      INNER JOIN dbo.DimDate dd ON fs.DateKey = dd.Datekey
      INNER JOIN dbo.DimProduct dp ON fs.ProductKey = dp.ProductKey
      INNER JOIN dbo.DimProductSubcategory dps ON dp.ProductSubcategoryKey = dps.
ProductSubcategoryKey
    INNER JOIN dbo.DimProductCategory dpc ON dps.ProductCategoryKey = dpc.ProductCategoryKey
GROUP BY dd.CalendarQuarter
      ,dpc.ProductCategoryName;