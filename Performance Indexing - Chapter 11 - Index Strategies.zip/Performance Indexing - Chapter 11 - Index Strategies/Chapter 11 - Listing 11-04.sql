--Listing 11-4.  Creating and Populating Table for Identity\Sequence Pattern
USE AdventureWorks2014
GO

IF OBJECT_ID('IndexStrategiesFruit_Identity') IS NOT NULL
	DROP TABLE IndexStrategiesFruit_Identity

CREATE TABLE dbo.IndexStrategiesFruit_Identity
(
FruitID int IDENTITY(1,1)
,FruitName varchar(25)
,Color varchar(10)
,CONSTRAINT PK_Fruit_FruitID_Idnt PRIMARY KEY CLUSTERED (FruitID)
);

INSERT INTO dbo.IndexStrategiesFruit_Identity(FruitName, Color)
VALUES('Apple','Red'),('Banana','Yellow'),('Apple','Green'),('Grape','Green');

SELECT FruitID, FruitName, Color
FROM dbo.IndexStrategiesFruit_Identity;

IF OBJECT_ID('IndexStrategiesFruit_Sequence') IS NOT NULL
	DROP TABLE IndexStrategiesFruit_Sequence

IF OBJECT_ID('FruitSequence') IS NOT NULL
	DROP SEQUENCE FruitSequence

CREATE SEQUENCE FruitSequence AS INTEGER
	START WITH 1;

CREATE TABLE dbo.IndexStrategiesFruit_Sequence
(
FruitID int DEFAULT NEXT VALUE FOR FruitSequence
,FruitName varchar(25)
,Color varchar(10)
,CONSTRAINT PK_Fruit_FruitID_Seq PRIMARY KEY CLUSTERED (FruitID)
);

INSERT INTO dbo.IndexStrategiesFruit_Sequence(FruitName, Color)
VALUES('Apple','Red'),('Banana','Yellow'),('Apple','Green'),('Grape','Green');

SELECT FruitID, FruitName, Color
FROM dbo.IndexStrategiesFruit_Sequence;

INSERT INTO dbo.IndexStrategiesFruit_Sequence
VALUES(6, 'Apple','Red')

