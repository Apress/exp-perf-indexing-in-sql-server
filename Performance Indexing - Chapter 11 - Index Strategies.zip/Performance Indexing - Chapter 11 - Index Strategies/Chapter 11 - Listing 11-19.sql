--Listing 11-19.  Covering Index Pattern
USE AdventureWorks2014
GO

SET STATISTICS IO ON;

SELECT ContactID, FirstName, LastName, IsActive
FROM dbo.Contacts
WHERE FirstName = 'Catherine'
AND LastName = 'Cox';
