--Listing 11-1.  Temporary Object with Heap
USE AdventureWorks2014
GO

IF OBJECT_ID('tempdb..##TempWithHeap') IS NOT NULL
	DROP TABLE ##TempWithHeap

CREATE TABLE ##TempWithHeap
  (
  SalesOrderID INT
  );

INSERT INTO ##TempWithHeap
SELECT SalesOrderID
FROM Sales.SalesOrderHeader
WHERE SalesPersonID = 283;

SELECT sod.* FROM Sales.SalesOrderDetail sod
  INNER JOIN ##TempWithHeap t ON t.SalesOrderID = sod.SalesOrderID;
GO