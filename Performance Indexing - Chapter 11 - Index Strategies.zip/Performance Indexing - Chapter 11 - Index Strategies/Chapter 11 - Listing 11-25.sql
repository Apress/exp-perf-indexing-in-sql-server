--Listing 11-25.  Filtered Index Pattern
USE AdventureWorks2014
GO

SET STATISTICS IO ON;

SELECT ContactID, FirstName, LastName, CertificationDate
FROM dbo.Contacts
WHERE CertificationDate IS NOT NULL
ORDER BY CertificationDate;

SELECT ContactID, FirstName, LastName, CertificationDate
FROM dbo.Contacts
WHERE CertificationDate BETWEEN '20110101' AND '20110201'
ORDER BY CertificationDate;