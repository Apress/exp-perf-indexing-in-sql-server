--Listing 11-2.  Temporary Object with Clustered Index
USE AdventureWorks2014
GO

IF OBJECT_ID('tempdb..##TempWithClusteredIX') IS NOT NULL
	DROP TABLE ##TempWithClusteredIX

CREATE TABLE ##TempWithClusteredIX
  (
  SalesOrderID INT PRIMARY KEY CLUSTERED
  )

INSERT INTO ##TempWithClusteredIX
SELECT SalesOrderID
FROM Sales.SalesOrderHeader
WHERE SalesPersonID = 283

SELECT sod.* FROM Sales.SalesOrderDetail sod
INNER JOIN ##TempWithClusteredIX t ON t.SalesOrderID = sod.SalesOrderID
GO