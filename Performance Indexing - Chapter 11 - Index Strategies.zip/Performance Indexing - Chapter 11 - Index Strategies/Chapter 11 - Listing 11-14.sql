--Listing 11-14.  Search Column Pattern
USE AdventureWorks2014
GO

SET STATISTICS IO ON ;

SELECT ContactID, FirstName FROM dbo.Contacts
WHERE FirstName = 'Catherine';