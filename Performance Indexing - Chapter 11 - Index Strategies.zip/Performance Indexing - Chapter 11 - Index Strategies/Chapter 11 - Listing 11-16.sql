--Listing 11-16.  Index Intersection Pattern
USE AdventureWorks2014
GO

SET STATISTICS IO ON;

SELECT ContactID, FirstName, LastName  FROM dbo.Contacts
WHERE FirstName = 'Catherine'
AND LastName = 'Cox';
