--Listing 11-24.  Other Queries Against Included Columns Pattern
USE AdventureWorks2014
GO

SET STATISTICS IO ON;

SELECT ContactID, FirstName FROM dbo.Contacts
WHERE FirstName = 'Catherine';

SELECT ContactID, FirstName, LastName FROM dbo.Contacts
WHERE FirstName = 'Catherine'
AND LastName = 'Cox';

SELECT ContactID, FirstName, LastName, IsActive FROM dbo.Contacts
WHERE FirstName = 'Catherine'
AND LastName = 'Cox';