--Listing 11-28.  Foreign Key Pattern
USE AdventureWorks2014
GO

SELECT MAX(c.CustomerID)
      FROM dbo.Customer c
      LEFT OUTER JOIN dbo.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID
      WHERE soh.CustomerID IS NULL;

SET STATISTICS IO ON;

DELETE FROM dbo.Customer
WHERE CustomerID = 701;