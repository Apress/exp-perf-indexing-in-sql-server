--Listing 11-15.  Search Column Pattern
USE AdventureWorks2014
GO

CREATE INDEX IX_Contacts_FirstName ON dbo.Contacts(FirstName);

SET STATISTICS IO ON;

SELECT ContactID, FirstName FROM dbo.Contacts
WHERE FirstName = 'Catherine';
