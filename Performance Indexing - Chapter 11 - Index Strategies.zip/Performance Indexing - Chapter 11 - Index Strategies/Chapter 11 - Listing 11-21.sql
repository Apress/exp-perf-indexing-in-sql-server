--Listing 11-21.  Included Columns Pattern
USE AdventureWorks2014
GO

SET STATISTICS IO ON;

SELECT ContactID, FirstName, LastName, EmailAddress FROM dbo.Contacts
WHERE FirstName = 'Catherine';